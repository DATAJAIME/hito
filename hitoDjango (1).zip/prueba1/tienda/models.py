from django.db import models

# Create your models here.
class Disco(models.Model):
    titulo = models.CharField(max_length=100)
    desc = models.TextField()
    precio = models.CharField(max_length=20)
    image = models.FilePathField(path="/img")