from django.shortcuts import render
from tienda.models import Disco

# Create your views here.
def tienda_index(request):
    tienda = Disco.objects.all()
    context = {
        'tienda': tienda
    }
    return render(request, 'index.html', context)

def discos(request, pk):
    disco = Disco.objects.get(pk=pk)
    context = {
        'disco': disco
    }
    return render(request, 'details.html', context)

def home_request(request):
    return render(request, 'home.html')