from django.urls import path
from tienda import views

urlpatterns = [
    path('catalogo/', views.tienda_index, name='tienda'),
    path("producto/<int:pk>/", views.discos, name="discos"),
    path('home/', views.home_request, name="home"),
    path('', views.home_request, name="home2"),
]